const express = require('express');
const app = express();




app.get('*',(req,res)=>{
    res.send('404 error');
});


app.listen(port,()=>{
    console.log(`Server Is Running At Port Number ${port}`);
})